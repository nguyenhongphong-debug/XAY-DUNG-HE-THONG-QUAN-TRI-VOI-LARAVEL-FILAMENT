export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  is_visible: boolean;
}

export type ProductStatus = 'draft' | 'published' | 'out_of_stock';

export interface Product {
  id: string;
  category_id: string;
  name: string;
  slug: string;
  description?: string;
  price: number;
  stock_quantity: number;
  image_path?: string;
  status: ProductStatus;
  discount_percent?: number;
}
