import { 
  collection, 
  onSnapshot, 
  query, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDoc,
  getDocs,
  where,
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// MSSV Prefix
const MSSV = 'sv23810310433';
const CATEGORIES_COL = `${MSSV}_categories`;
const PRODUCTS_COL = `${MSSV}_products`;

export const testConnection = async () => {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    }
  }
};

export const getCategories = (callback: (data: any[]) => void) => {
  const q = query(collection(db, CATEGORIES_COL), orderBy('name'));
  return onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(data);
  }, (error) => handleFirestoreError(error, OperationType.LIST, CATEGORIES_COL));
};

export const addCategory = async (data: any) => {
  try {
    return await addDoc(collection(db, CATEGORIES_COL), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, CATEGORIES_COL);
  }
};

export const updateCategory = async (id: string, data: any) => {
  try {
    return await updateDoc(doc(db, CATEGORIES_COL, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${CATEGORIES_COL}/${id}`);
  }
};

export const deleteCategory = async (id: string) => {
  try {
    return await deleteDoc(doc(db, CATEGORIES_COL, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${CATEGORIES_COL}/${id}`);
  }
};

export const getProducts = (callback: (data: any[]) => void, filters?: { categoryId?: string }) => {
  let q = query(collection(db, PRODUCTS_COL), orderBy('name'));
  if (filters?.categoryId) {
    q = query(collection(db, PRODUCTS_COL), where('category_id', '==', filters.categoryId), orderBy('name'));
  }
  return onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(data);
  }, (error) => handleFirestoreError(error, OperationType.LIST, PRODUCTS_COL));
};

export const addProduct = async (data: any) => {
  try {
    return await addDoc(collection(db, PRODUCTS_COL), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, PRODUCTS_COL);
  }
};

export const updateProduct = async (id: string, data: any) => {
  try {
    return await updateDoc(doc(db, PRODUCTS_COL, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${PRODUCTS_COL}/${id}`);
  }
};

export const deleteProduct = async (id: string) => {
  try {
    return await deleteDoc(doc(db, PRODUCTS_COL, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${PRODUCTS_COL}/${id}`);
  }
};
