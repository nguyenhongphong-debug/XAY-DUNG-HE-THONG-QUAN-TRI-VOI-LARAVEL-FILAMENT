import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '../../components/ui/form';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { Checkbox } from '../../components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { addCategory, updateCategory, getCategories } from '../../lib/db';
import { toast } from 'sonner';
import { ArrowLeft, Loader2 } from 'lucide-react';

const MSSV = 'sv23810310433';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  slug: z.string().min(2, 'Slug must be at least 2 characters'),
  description: z.string().optional(),
  is_visible: z.boolean(),
});

type FormValues = z.infer<typeof formSchema>;

export default function CategoryForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = React.useState(false);
  const [isFetching, setIsFetching] = React.useState(!!id);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      slug: '',
      description: '',
      is_visible: true,
    },
  });

  const nameValue = form.watch('name');

  // Auto-generate slug from name
  React.useEffect(() => {
    if (!id && nameValue) {
      const slug = nameValue
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      
      const prefix = `${MSSV}-`;
      const finalSlug = slug.startsWith(prefix) ? slug : `${prefix}${slug}`;
      form.setValue('slug', finalSlug);
    }
  }, [nameValue, id, form]);

  React.useEffect(() => {
    if (id) {
      const unsub = getCategories((cats) => {
        const cat = cats.find(c => c.id === id);
        if (cat) {
          form.reset({
            name: cat.name,
            slug: cat.slug,
            description: cat.description || '',
            is_visible: cat.is_visible,
          });
        }
        setIsFetching(false);
      });
      return () => unsub();
    }
  }, [id, form]);

  const onSubmit = async (values: FormValues) => {
    setIsLoading(true);
    try {
      // Ensure slug has MSSV prefix
      const prefix = `${MSSV}-`;
      if (!values.slug.startsWith(prefix)) {
        values.slug = `${prefix}${values.slug}`;
      }

      if (id) {
        await updateCategory(id, values);
        toast.success('Category updated successfully');
      } else {
        await addCategory(values);
        toast.success('Category created successfully');
      }
      navigate('/categories');
    } catch (error) {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (isFetching) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/categories')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-bold tracking-tight">
          {id ? 'Edit Category' : 'New Category'}
        </h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Category Details</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Electronics, Clothing, etc." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="sv23810310433-electronics" {...field} />
                    </FormControl>
                    <FormDescription>
                      The slug is used in the URL. It will be prefixed with your MSSV.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Input placeholder="Brief description of the category" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="is_visible"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Visible</FormLabel>
                      <FormDescription>
                        This category will be visible to users in the store.
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-4">
                <Button variant="outline" type="button" onClick={() => navigate('/categories')}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {id ? 'Update Category' : 'Create Category'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
