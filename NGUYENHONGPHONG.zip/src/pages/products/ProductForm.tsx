import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '../../components/ui/form';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { RichTextEditor } from '../../components/RichTextEditor';
import { addProduct, updateProduct, getProducts, getCategories } from '../../lib/db';
import { Category, ProductStatus } from '../../types';
import { toast } from 'sonner';
import { ArrowLeft, Loader2, Package, Upload } from 'lucide-react';

const MSSV = 'sv23810310433';

const formSchema = z.object({
  category_id: z.string().min(1, 'Please select a category'),
  name: z.string().min(2, 'Name must be at least 2 characters').max(200),
  slug: z.string().min(2, 'Slug must be at least 2 characters'),
  description: z.string().optional(),
  price: z.number().min(0, 'Price cannot be negative'),
  stock_quantity: z.number().int('Stock must be an integer').min(0, 'Stock cannot be negative'),
  image_path: z.string().url('Please enter a valid URL').or(z.string().length(0)).optional(),
  status: z.enum(['draft', 'published', 'out_of_stock']),
  discount_percent: z.number().min(0).max(100).optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function ProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = React.useState(false);
  const [isFetching, setIsFetching] = React.useState(true);
  const [categories, setCategories] = React.useState<Category[]>([]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      category_id: '',
      name: '',
      slug: '',
      description: '',
      price: 0,
      stock_quantity: 0,
      image_path: '',
      status: 'draft',
      discount_percent: 0,
    },
  });

  const nameValue = form.watch('name');

  // Auto-generate slug from name
  React.useEffect(() => {
    if (!id && nameValue) {
      const slug = nameValue
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      
      const prefix = `${MSSV}-`;
      const finalSlug = slug.startsWith(prefix) ? slug : `${prefix}${slug}`;
      form.setValue('slug', finalSlug);
    }
  }, [nameValue, id, form]);

  React.useEffect(() => {
    const unsubCats = getCategories(setCategories);
    
    if (id) {
      const unsubProds = getProducts((prods) => {
        const prod = prods.find(p => p.id === id);
        if (prod) {
          form.reset({
            category_id: prod.category_id,
            name: prod.name,
            slug: prod.slug,
            description: prod.description || '',
            price: prod.price,
            stock_quantity: prod.stock_quantity,
            image_path: prod.image_path || '',
            status: prod.status,
            discount_percent: prod.discount_percent || 0,
          });
        }
        setIsFetching(false);
      });
      return () => {
        unsubCats();
        unsubProds();
      };
    } else {
      setIsFetching(false);
      return () => unsubCats();
    }
  }, [id, form]);

  const onSubmit = async (values: FormValues) => {
    setIsLoading(true);
    try {
      // Ensure slug has MSSV prefix
      const prefix = `${MSSV}-`;
      if (!values.slug.startsWith(prefix)) {
        values.slug = `${prefix}${values.slug}`;
      }

      if (id) {
        await updateProduct(id, values);
        toast.success('Product updated successfully');
      } else {
        await addProduct(values);
        toast.success('Product created successfully');
      }
      navigate('/products');
    } catch (error) {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  if (isFetching) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/products')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-bold tracking-tight">
          {id ? 'Edit Product' : 'New Product'}
        </h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Left Column - Main Info */}
            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>General Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Product Name</FormLabel>
                        <FormControl>
                          <Input placeholder="iPhone 15 Pro, Nike Air Max, etc." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="slug"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Slug</FormLabel>
                        <FormControl>
                          <Input placeholder="sv23810310433-iphone-15-pro" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <RichTextEditor 
                            content={field.value || ''} 
                            onChange={field.onChange} 
                            placeholder="Describe your product in detail..."
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Pricing & Inventory</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price (VNĐ)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="stock_quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stock Quantity</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" step="1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="discount_percent"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Discount Percent (%)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" max="100" {...field} />
                        </FormControl>
                        <FormDescription>Creative field: Special discount for this product.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Sidebar Info */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Organization</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="category_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {categories.map(cat => (
                              <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="draft">Draft</SelectItem>
                            <SelectItem value="published">Published</SelectItem>
                            <SelectItem value="out_of_stock">Out of Stock</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Product Image</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-square rounded-lg border-2 border-dashed flex flex-col items-center justify-center bg-muted overflow-hidden relative group">
                    {form.watch('image_path') ? (
                      <img 
                        src={form.watch('image_path')} 
                        alt="Preview" 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <>
                        <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-xs text-muted-foreground text-center px-4">Enter an image URL below to preview</p>
                      </>
                    )}
                  </div>
                  <FormField
                    control={form.control}
                    name="image_path"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Image URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://example.com/image.jpg" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <div className="flex flex-col gap-3">
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  {id ? 'Update Product' : 'Create Product'}
                </Button>
                <Button variant="outline" type="button" className="w-full" onClick={() => navigate('/products')}>
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
