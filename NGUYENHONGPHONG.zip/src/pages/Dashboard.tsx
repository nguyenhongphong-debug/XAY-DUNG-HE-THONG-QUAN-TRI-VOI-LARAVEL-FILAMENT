import React from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  Package, 
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { getCategories, getProducts } from '../lib/db';
import { Category, Product } from '../types';

export default function Dashboard() {
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [products, setProducts] = React.useState<Product[]>([]);

  React.useEffect(() => {
    const unsubCats = getCategories(setCategories);
    const unsubProds = getProducts(setProducts);
    return () => {
      unsubCats();
      unsubProds();
    };
  }, []);

  const stats = [
    { 
      label: 'Total Categories', 
      value: categories.length, 
      icon: Layers, 
      color: 'text-blue-600',
      bg: 'bg-blue-100'
    },
    { 
      label: 'Total Products', 
      value: products.length, 
      icon: Package, 
      color: 'text-emerald-600',
      bg: 'bg-emerald-100'
    },
    { 
      label: 'Published Products', 
      value: products.filter(p => p.status === 'published').length, 
      icon: TrendingUp, 
      color: 'text-indigo-600',
      bg: 'bg-indigo-100'
    },
    { 
      label: 'Out of Stock', 
      value: products.filter(p => p.status === 'out_of_stock' || p.stock_quantity === 0).length, 
      icon: AlertCircle, 
      color: 'text-red-600',
      bg: 'bg-red-100'
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your Admin Panel overview, Nguyễn Hồng Phong.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
              <div className={`${stat.bg} ${stat.color} p-2 rounded-lg`}>
                <stat.icon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {products.slice(0, 5).map(product => (
                <div key={product.id} className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded bg-muted flex items-center justify-center overflow-hidden">
                    {product.image_path ? (
                      <img src={product.image_path} alt={product.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <Package className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <p className="text-sm font-medium">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.price.toLocaleString('vi-VN')} VNĐ</p>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                    product.status === 'published' ? 'bg-emerald-100 text-emerald-700' :
                    product.status === 'draft' ? 'bg-gray-100 text-gray-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {product.status}
                  </div>
                </div>
              ))}
              {products.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No products found.</p>}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categories.slice(0, 5).map(category => (
                <div key={category.id} className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded bg-muted flex items-center justify-center">
                    <Layers className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div className="flex-grow">
                    <p className="text-sm font-medium">{category.name}</p>
                    <p className="text-xs text-muted-foreground">{category.slug}</p>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                    category.is_visible ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {category.is_visible ? 'Visible' : 'Hidden'}
                  </div>
                </div>
              ))}
              {categories.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No categories found.</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
